# Arsenal-Resources

An open source repository for the official 16x16 version of the textures for the Arsenal Mod and Plugin, by its developer, GamerCoder.

## Important

**3/9/23 Announcement**
For using the [Bukkit Version](https://github.com/GamerCoder215/Arsenal-Resources/tree/download) of the Resource Pack, it is recommended you use [OptiFine](https://optifine.net) for the best effect at textures.
